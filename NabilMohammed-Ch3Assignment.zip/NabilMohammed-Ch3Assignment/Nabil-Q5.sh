#! /usr/bin/bash

read -p "Please Enter the file you want to check: " FILE

# if the file demanded is REGUALR
if [ -f "$FILE" ]
  then
    echo "$FILE is a reguler file"
# if the file demanded is DIRECTORY
elif [ -d "$FILE" ]
  then
    echo "$FILE is a directory"
# if the file demanded is ANOTHER TYPE OF FILE
else
    echo "$FILE is another type of file"
# End of if    
fi
# showing message with more details
echo More info about the file you asked for
ls -l $FILE