#! /usr/bin/bash

#Showing all permissions a user has in the current directory

#Asking for name input
read -p "Enter Your Name: " NAME
#Showing message
echo Hello $NAME, Below are your permissions in the current directory
#The below will show all permissions
ls -lg
