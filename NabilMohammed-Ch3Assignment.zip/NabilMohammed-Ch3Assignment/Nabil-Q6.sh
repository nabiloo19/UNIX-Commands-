#! /usr/bin/bash

#creating the file
touch simplefile.txt
#Permission specified for the Owner
chmod u=rwx simplefile.txt
#Permission specified for the Group and Others
chmod g+rx,o+rx simplefile.txt
#Showing the permission settings
ls -dl ./simplefile.txt