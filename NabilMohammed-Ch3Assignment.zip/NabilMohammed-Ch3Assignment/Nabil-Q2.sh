#! /usr/bin/bash

#Showing message
read -p "Enter Your Name: " NAME
#Command to move a list of files to a new folder
mv {101.jpg,202.jpg,303.jpg} ./new_folder
#Showing message of successfyully moving data and showing the moved list of files' details
echo $NAME, all files have been sent to your designated folder. Here is a list of the files in the new folder:-
ls ./new_folder

