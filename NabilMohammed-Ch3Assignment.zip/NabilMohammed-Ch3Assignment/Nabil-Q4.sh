#! /usr/bin/bash

#reserving animals' names
AllAnimals="man bear pig dog cat sheep"

#Showing Message
echo Animals Names in new line are listed below:-

#Looping through all the names
for PartAnimals in $AllAnimals
  do
    echo $PartAnimals
  done