#! /usr/bin/bash

#We will use if-else statments to validate the exitence of the shadow file

#If it exists
if [[ -f /etc/shadow ]]
then
#success message of passwords exsitence
    echo "Shadow passwords are enabled."
elif [[ -w /etc/shadow ]]
then
#success message for having permission
    echo "You have permissions to edit /etc/shadow."
else
#error message for NOT having permission
    echo "You do NOT have permissions to edit /etc/shadow."
#End of if-else statments
fi