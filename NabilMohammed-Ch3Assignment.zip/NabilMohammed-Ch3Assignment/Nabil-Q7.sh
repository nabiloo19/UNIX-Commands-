#! /usr/bin/bash

#Accepting 2 numbers from the user and reserve them in variables
read -p "Enter 1st Number:- " NUM1
read -p "Enter 2nd Number:- " NUM2

#Choosing an operation to excute
echo "Enter an operation to excute:- "
echo 1. Add
echo 2. Subtract
echo 3. Multiply
echo 4. Divide
echo 5. Exit

#Accepting an operation
read OP 

#Begin Cases
case $OP in
#If 1 is chosen, we go with Addition
    1)echo Addition of $NUM1 and $NUM2 is
        SUM=$((NUM1+NUM2))
        echo $SUM
    ;;
#If 2 is chosen, we go with Subtraction
    2)echo Subtraction of $NUM1 and $NUM2 is
        SUM=$((NUM1-NUM2))
        echo $SUM
    ;;
#If 3 is chosen, we go with Mutlpilcation
    3)echo Mutlpilcation of $NUM1 and $NUM2 is
        SUM=$((NUM1*NUM2))
        echo $SUM
    ;;
#If 4 is chosen, we go with Division
    4)echo Division of $NUM1 and $NUM2 is
        SUM=$((NUM1/NUM2))
        echo $SUM
    ;;
#If 5 is chosen, we go with Closing
    5)echo Bye
    ;;
#If ANY number is chosen other than mentioned, we go with a simple message
    *)echo ONLY CHOOSE FROM THE LIST
esac
